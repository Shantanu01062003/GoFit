<?php  
    session_start();
    include('../dbconnect.php');
    $currentDate = date("Y-m-d");
    $email = $_SESSION['email'];

    $apple = $_POST['apple_quantity'];
    $banana = $_POST['banana_quantity'];
    $mango = $_POST['mango_quantity'];
    $orange = $_POST['orange_quantity'];
    $papaya = $_POST['papaya_quantity'];
    $grapes = $_POST['grapes_quantity'];
    $mushroom = $_POST['mushroom'];
    $Total;
    
    




    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Pepsi' and Food_Category = 'Soda&SoftDrinks' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        //$val = 300; //paneer cal
        $cals = (int)$val*(int)$apple*2.3;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Soft_Drinks`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Pepsi' and Food_Category = 'Soda&SoftDrinks'";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 300;
        $cals = (int)$val*(int)$apple*2.3;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Soft_Drinks = Soft_Drinks + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }






    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Coke' and Food_Category = 'Soda&SoftDrinks' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$banana*2.5;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Soft_Drinks`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Coke' and Food_Category = 'Soda&SoftDrinks' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$banana*2.5;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Soft_Drinks = Soft_Drinks + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }







    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Tomato' and Food_Category = 'Vegetables' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 100;
        $cals = (int)$val*(int)$mango;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Soft_Drinks`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Tomato' and Food_Category = 'Vegetables' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 100;
        $cals = (int)$val*(int)$mango;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Soft_Drinks = Soft_Drinks + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }







    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Tomato' and Food_Category = 'Vegetables' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 170;
        $cals = (int)$val*(int)$orange;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Soft_Drinks`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Tomato' and Food_Category = 'Vegetables' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 170;
        $cals = (int)$val*(int)$orange;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Soft_Drinks = Soft_Drinks + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }








    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Sprite' and Food_Category = 'Soda&SoftDrinks'  ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$papaya*2.5;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Soft_Drinks`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories  where Food_Item = 'Sprite' and Food_Category = 'Soda&SoftDrinks'  ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$papaya*2.5;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Soft_Drinks = Soft_Drinks + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }








    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories  where Food_Item = 'Cauliflower' and Food_Category = 'Vegetables'  ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 100;
        $cals = (int)$val*(int)$grapes;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Soft_Drinks`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Cauliflower' and Food_Category = 'Vegetables' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 100;
        $cals = (int)$val*(int)$grapes;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Soft_Drinks = Soft_Drinks + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }










    header("Location: ../../webpages/dietchoices.php");
    //$Total = (int)$apple + (int)$banana + (int)$orange + (int)$mango + (int)$papaya + (int)$grapes + (int)$pastries + (int)$cheese;
    $query = "UPDATE food_intake SET Total = Total+$Total WHERE Email = '$email' and Date = '$currentDate'"; 
    mysqli_query($conn,$query);


?>


