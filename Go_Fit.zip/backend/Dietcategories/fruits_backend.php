<?php  
    session_start();
    include('../dbconnect.php');
    $currentDate = date("Y-m-d");
    $email = $_SESSION['email'];

    $apple = $_POST['apple_quantity'];
    $banana = $_POST['banana_quantity'];
    $mango = $_POST['mango_quantity'];
    $orange = $_POST['orange_quantity'];
    $papaya = $_POST['papaya_quantity'];
    $grapes = $_POST['grapes_quantity'];
    $Total;
    
    
    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Apple' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$apple;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Fruits`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Apple' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$apple;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET fruits = fruits + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }




    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Banana' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$banana;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Fruits`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Banana' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$banana;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET fruits = fruits + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }





    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Grapes' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$grapes;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Fruits`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Grapes' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$grapes;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET fruits = fruits + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }





    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Orange' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$orange;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Fruits`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Orange' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$orange;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET fruits = fruits + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }






    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Mango' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$mango;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Fruits`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Mango' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$mango;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET fruits = fruits + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }






    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Papaya' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$papaya;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Fruits`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
        
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Papaya' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$papaya;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET fruits = fruits + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }

    header("Location: ../../webpages/dietchoices.php");
    $query = "UPDATE food_intake SET Total = Total+$Total WHERE Email = '$email' and Date = '$currentDate'"; 
    mysqli_query($conn,$query);

?>
