<?php  
    session_start();
    include('../dbconnect.php');
    $currentDate = date("Y-m-d");
    $email = $_SESSION['email'];

    $apple = $_POST['apple_quantity'];
    $banana = $_POST['banana_quantity'];
    $mango = $_POST['mango_quantity'];
    $orange = $_POST['orange_quantity'];
    $papaya = $_POST['papaya_quantity'];
    // $grapes = $_POST['grapes_quantity'];
    $cheese = $_POST['cheese'];
    $pastries = $_POST['pastries'];
    $Total;
    
    
    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Milk' and Food_Category = 'Milk&DairyProducts' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$apple * 2;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Milk' and Food_Category = 'Milk&DairyProducts' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$apple*2;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }




    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Curd' and Food_Category = 'Milk&DairyProducts' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$banana*1.28;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Curd' and Food_Category = 'Milk&DairyProducts' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$banana*1.28;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }





    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Lassi' and Food_Category = 'Milk&DairyProducts' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$mango*3;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Lassi' and Food_Category = 'Milk&DairyProducts' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$mango*3;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }





    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Yogurt' and Food_Category = 'Yogurt' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$orange*2.27;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Yogurt' and Food_Category = 'Yogurt' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$orange*2.27;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }






    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where  Food_Item = 'Vanilla Ice Cream' and Food_Category = 'IceCream' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$papaya*1.25;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where  Food_Item = 'Vanilla Ice Cream' and Food_Category = 'IceCream' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = (int)$val*(int)$papaya*1.25;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }






    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        //$calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Plain Yoghurt' and Food_Category = 'Yoghurt' ";
        //$query_run = mysqli_query($conn,$calory) ;
        //$val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 71;
        $cals = (int)$val*(int)$grapes;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Papaya' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 71;
        $cals = (int)$val*(int)$grapes;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }







    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Cheddar' and Food_Category = 'Cheese' ";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = ((int)$val*(int)$cheese)/100;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
    }
    else
    {
        $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Cheddar' and Food_Category = 'Cheese'";
        $query_run = mysqli_query($conn,$calory) ;
        $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $cals = ((int)$val*(int)$cheese)/100;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
    }






    $query = "SELECT * FROM food_intake where Email = '$email' and Date = '$currentDate'";
    if(mysqli_num_rows(mysqli_query($conn,$query)) == 0)
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Papaya' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val =500;
        $cals = (int)$val*(int)$pastries;
        $Total += (int)$cals;
        $query = "INSERT INTO `food_intake` (`Email`, `Date`, `Dairy_Products`) VALUES ('$email', '$currentDate', '$cals');"; 
        mysqli_query($conn,$query);
        header("Location: ../../webpages/dietchoices.php");
        
    }
    else
    {
        // $calory = "SELECT Cals_Per_100_Grams FROM calories where Food_Item = 'Papaya' ";
        // $query_run = mysqli_query($conn,$calory) ;
        // $val = mysqli_fetch_array(mysqli_query($conn,$calory))[0];
        $val = 500;
        $cals = (int)$val*(int)$pastries;
        $Total += (int)$cals;
        $query = "UPDATE food_intake SET Dairy_Products = Dairy_Products + $cals WHERE Email = '$email' and Date = '$currentDate'"; 
        mysqli_query($conn,$query);
        header("Location: ../../webpages/dietchoices.php");
    }

    
    //$Total = (int)$apple + (int)$banana + (int)$orange + (int)$mango + (int)$papaya + (int)$grapes + (int)$pastries + (int)$cheese;
    $query = "UPDATE food_intake SET Total = Total+$Total WHERE Email = '$email' and Date = '$currentDate'"; 
    mysqli_query($conn,$query);


?>


