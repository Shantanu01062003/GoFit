// Assume you have captured the HTML content you want to send to the backend
var htmlContent = document.getElementById('selectedFruitDetails').innerHTML;

// Make an AJAX request to send the HTML content to the backend
var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
            // Handle successful response from the backend if needed
            console.log('Data sent to the backend successfully.');
        } else {
            // Handle errors if any
            console.error('Error sending data to the backend:', xhr.statusText);
        }
    }
};
xhr.open('POST', 'fruits_backend.php', true);
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xhr.send('htmlContent=' + encodeURIComponent(htmlContent));
