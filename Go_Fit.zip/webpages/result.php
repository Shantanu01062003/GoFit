<?php
    session_start();
    if(!isset($_SESSION['User']))  
    {
        header("Location: login.php?msg=Please login first!");
        session_destroy();
    }
    include('../backend/dbconnect.php');
    $email = $_SESSION['email'];


    $query = "SELECT COALESCE(SUM(Water), 0) FROM water_intake WHERE Email = '$email';";
    $water = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Sleep), 0) FROM sleep WHERE Email = '$email';";
    $sleep = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(sum(Total), 0) FROM food_intake WHERE Email = '$email';";
    $calory = mysqli_fetch_array(mysqli_query($conn, $query))[0];





    $query = "SELECT COUNT(*) FROM sleep WHERE Email = '$email';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        if ($row[0] > 0) {
            // Update cnt2
            $cnt_sleep = $row[0];
        } else {
            // Set cnt2 to 1
            $cnt_sleep = 1;
        }
    } else {
        // Handle query error
        $cnt_sleep = 1; // Default to 1 in case of error
    }




    $query = "SELECT COUNT(*) FROM water_intake WHERE Email = '$email';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        if ($row[0] > 0) {
            // Update cnt2
            $cnt_water = $row[0];
        } else {
            // Set cnt2 to 1
            $cnt_water = 1;
        }
    } else {
        // Handle query error
        $cnt_water = 1; // Default to 1 in case of error
    }




    $query = "SELECT COUNT(*) FROM food_intake WHERE Email = '$email';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        if ($row[0] > 0) {
            // Update cnt2
            $cnt_calory = $row[0];
        } else {
            // Set cnt2 to 1
            $cnt_calory = 1;
        }
    } else {
        // Handle query error
        $cnt_calory = 1; // Default to 1 in case of error
    }






    $water = round(($water / $cnt_water),2);
    $sleep = round(($sleep / $cnt_sleep),2);
    $cal = round(($calory / $cnt_calory),2)/1000;



    $currentDate = date("Y-m-d");
    $email = $_SESSION['email'];



 
 
    $query = "SELECT COALESCE(Water, 0) FROM water_intake WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $water1 = isset($row[0]) ? number_format($row[0], 2) : 0;
    } else {
        $water1 = 0; // Set default value to 0 if query fails
    }

    $query = "SELECT COALESCE(Sleep, 0) FROM sleep WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $sleep1 = $row ? $row[0] : 0;
    } else {
        $sleep1 = 0; // Set default value to 0 if query fails
    }


    $query = "SELECT COALESCE(Total, 0) FROM food_intake WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $cal1 = isset($row[0]) ? number_format($row[0], 3) : 0;

    } else {
        $cal1 = 0; // Set default value to 0 if query fails
    }

    $cal1 = $cal1/1000;


?>
<?php include 'components/navbar.php' ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel="stylesheet" href="../styling/result.css">
        <title>Result</title>
        <style>
  /* Style for accordion */
 
  
</style>
    </head>
    <body>
        

<div>
    <h3>Your Activities</h3>
    <div class="row">
        <div class="card">
            <a href="result_physical.php">
            <img class="card-img-top" src="../images/phy.jpg" alt="Card image cap">

                <div class="card-body">
                    <h5 class="card-title">Physical Activities</h5>
                    
                </div>
            </a>
        </div>
        <div class="card">
            <a href="result_stress.php">
            <img class="card-img-top" src="../images/sleep.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Stress Relieving Activities</h5>
                
            </div>
            </a>
        </div>
        <div class="card">
            <a href="result_diet.php">
            <img class="card-img-top" src="../images/calories.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Diet</h5>
                
            </div>
</a>
        </div>
    </div>
</div>


 
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>    </body>

</html>
