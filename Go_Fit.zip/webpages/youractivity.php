   <?php
    session_start();
    include('../backend/dbconnect.php');
    // Dummy data
    $currentDate = date("Y-m-d");
    $email = $_SESSION['email'];
    $query = "SELECT * FROM physical_activity WHERE Email = '$email' and date='$currentDate';";
    $result = mysqli_query($conn, $query);    
    $phyTotal = 0;
    $stressTotal = 0;
    $calTotal = 0;
    // $jog = mysqli_fetch_array(mysqli_query($conn, $query))[6];

    if (mysqli_num_rows($result) > 0) {
    // Fetch data from the first row (assuming there's only one row for the current date)
    $row = mysqli_fetch_array($result);
    
    // Extract data from the row
    $jog = $row[2];
    $exercise = $row[3];
    $cycling = $row[4];
    $playing = $row[5];
    $hiking = $row[6];
    $other_physical = $row[7];
    $phyTotal= $jog+$exercise+$cycling+$playing+$hiking+$other_physical;
    
    // Define the phyData array
    $phyData = array(
        "Jogging" => $jog,
        "Exercise" => $exercise,
        "Cycling" => $cycling,
        "Playing" => $playing,
        "Hiking" => $hiking,
        "Others" => $other_physical
    );
} else {
    // If no data is present for the current date, set the phyData to display the message
    $phyData = array("No Physical Activities Performed" => 1);
}

    $query2 = "SELECT * FROM stress_activity WHERE Email = '$email' and date='$currentDate';";
    $result2 = mysqli_query($conn, $query2);    
    // $jog = mysqli_fetch_array(mysqli_query($conn, $query))[6];

    if (mysqli_num_rows($result2) > 0) {
    // Fetch data from the first row (assuming there's only one row for the current date)
    $row2 = mysqli_fetch_array($result2);
    
    // Extract data from the row
    $listeningMusic = $row2[2];
    $dancing = $row2[3];
    $talking = $row2[4];
    $chanting = $row2[5];
    $yoga = $row2[6];
    $meditation = $row2[7];
    $writing = $row2[8];
    $playingInst = $row2[9];
    $Other_stress = $row2[10];
    $stressTotal= $listeningMusic+$dancing+$talking+$chanting+$yoga+$meditation+$writing+$playingInst+$Other_stress;
    
    // Define the phyData array
    $stressData = array(
        "Listening Music" => $listeningMusic,
        "Dancing" => $dancing,
        "Talking" => $talking,
        "Chanting" => $chanting,
        "Yoga" => $yoga,
        "Meditation" => $meditation,
        "Writing" => $writing,
        "Playing Instrument" => $playingInst,
        "Others" => $Other_stress
    );
} else {
    // If no data is present for the current date, set the phyData to display the message
    $stressData = array("No Stress Relieving  Activities Performed" => 1);
}

    $query3 = "SELECT * FROM food_intake WHERE Email = '$email' and date='$currentDate';";
    $result = mysqli_query($conn, $query3);    
    // $jog = mysqli_fetch_array(mysqli_query($conn, $query))[6];

    if (mysqli_num_rows($result) > 0) {
    // Fetch data from the first row (assuming there's only one row for the current date)
    $row = mysqli_fetch_array($result);
    
    // Extract data from the row
    $nonveg = $row[0];
    $veg = $row[3];
    $chapati = $row[4];
    $dairy = $row[5];
    $fruit = $row[6];
    $soft = $row[7];
    $junk = $row[8];
    $cereal = $row[10];
    $calTotal = $row[9];
    // Define the phyData array
    $foodData = array(
        "Non-Veg Food" => $nonveg,
        "Veg Food" => $veg,
        "Chapati/Rice" => $chapati,
        "Dariy Products" => $dairy,
        "Soft Drinks" => $soft,
        "Fruits" => $fruit,
        "Junk-Food" => $junk,
        "Cereals" => $cereal
    );
} else {
    // If no data is present for the current date, set the phyData to display the message
    $foodData = array("No Food Consumed Today" => 1);
}

    $query4 = "SELECT * FROM water_intake WHERE Email = '$email' and date='$currentDate';";
    $avgWater = "SELECT AVG(Water) FROM water_intake WHERE Email = '$email'";

    $result = mysqli_query($conn, $query4);    
    $result2 = mysqli_query($conn, $avgWater);    
    // $jog = mysqli_fetch_array(mysqli_query($conn, $query))[6];

    if (mysqli_num_rows($result) > 0) {
    // Fetch data from the first row (assuming there's only one row for the current date)
    $row = mysqli_fetch_array($result);
    $row2 = mysqli_fetch_array($result2);
    
    // Extract data from the row
    $water = $row[2];
    $avgWater = $row2[0];
    $waterData = array(
        "Water" => $water,
        "Average " =>$avgWater
    );

} else {
    // If no data is present for the current date, set the phyData to display the message
    $waterData = array("No " => 1);
}

    $query = "SELECT * FROM sleep WHERE Email = '$email' and date='$currentDate';";
    $avg = "SELECT AVG(Sleep) FROM sleep WHERE Email = '$email'";

    $result = mysqli_query($conn, $query);    
    $result2 = mysqli_query($conn, $avg);    
    // $jog = mysqli_fetch_array(mysqli_query($conn, $query))[6];

    if (mysqli_num_rows($result) > 0) {
    // Fetch data from the first row (assuming there's only one row for the current date)
    $row = mysqli_fetch_array($result);
    $row2 = mysqli_fetch_array($result2);
    
    // Extract data from the row
    $sleep = $row[2];
    $avgsleep = $row2[0];
    $sleepData = array(
        "Sleep" => $sleep,
        "Average" =>$avgsleep
    );

} else {
    // If no data is present for the current date, set the phyData to display the message
    $sleepData = array("No " => 1);
}




    ?>  
<?php include 'navbarmain.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="../styling/dietchoices.css">

</head>
<body>
    <div class="container">
    <h3>Today's Activities</h3>
    <div class="row m-2">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body d-flex flex-column justify-content-center align-items-center">
                    <h6>Physical Activities</h6>
                    <div style="width: 300px; height: 300px;">
                        <canvas id="myPieChart1"></canvas>
                    </div>
                    <p class="card-text mt-2">Total time: <?php echo (int)($phyTotal/60);echo"hr ";echo (int)($phyTotal%60);  ?>min </p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body d-flex flex-column justify-content-center align-items-center">
                    <h6>Stress Relieving Activities</h6>
                    <div style="width: 300px; height: 300px;">
                        <canvas id="myPieChart2"></canvas>
                    </div>
                    <p class="card-text mt-2">Total Time: <?php echo (int)($stressTotal/60);echo"hr ";echo (int)($stressTotal%60);  ?>min</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body d-flex flex-column justify-content-center align-items-center">
                    <h6>Calories Consumed</h6>
                    <div style="width: 300px; height: 300px;">
                        <canvas id="myPieChart3"></canvas>
                    </div>
                    <p class="card-text mt-2">Total Calories: <?php echo ($calTotal/1000);?> Kj</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row m-2">
        <div class="col-md-6">
            <div class="card">
                <div style="width: 500px; margin: 0 auto;">
                    <canvas id="myChart"></canvas>
                </div>
                <div class="card-body">
                    <p class="card-text">Water Consumption</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div style="width: 500px; margin: 0 auto;">
                    <canvas id="myChart2"></canvas>
                </div>
                <div class="card-body">
                    <p class="card-text">Sleeping Hours</p>
                </div>
            </div>
        </div>
    </div>
</div>


    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <script>
        // PHP to JavaScript data conversion
        var phyData = <?php echo json_encode($phyData); ?>;
        var stressData = <?php echo json_encode($stressData); ?>;
        var foodData = <?php echo json_encode($foodData); ?>;
    
        var waterData = <?php echo json_encode($waterData); ?>;
        var labels = Object.keys(waterData);
        var values = Object.values(waterData);

        var sleepData = <?php echo json_encode($sleepData); ?>;
        var labels2 = Object.keys(sleepData);
        var values2 = Object.values(sleepData);

        // Get canvas elements
        var ctx1 = document.getElementById('myPieChart1').getContext('2d');
        var ctx2 = document.getElementById('myPieChart2').getContext('2d');
        var ctx3 = document.getElementById('myPieChart3').getContext('2d');
        var ctx4 = document.getElementById('myChart').getContext('2d');

        // Create pie charts
        if (Object.keys(phyData).length !== 0) {
        var myPieChart1 = new Chart(ctx1, {
            type: 'pie',
            data: {
                labels: Object.keys(phyData),
                datasets: [{
                    label: 'Minutes',
                    data: Object.values(phyData),
                    backgroundColor: [
                        '#92C7CF',
                        '#B5C0D0',
                        '#CCD3CA',
                        '#F5E8DD',
                        '#EED3D9',
                        '#F1FADA',
                    ],
                    
                    borderWidth: 0.4
                    
                }]
            },
            options: {
                responsive: false, // Make chart not responsive
                          aspectRatio: 1,
                plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                }
            }
        //         legend: {
        //         position: 'right', // Place legends at the bottom
        //         align: 'middle' // Align legends to the center
        // }
        
            }
        });
    }

    if (Object.keys(stressData).length !== 0) {
        var myPieChart2 = new Chart(ctx2, {
            type: 'pie',
            data: {
                labels: Object.keys(stressData),
                datasets: [{
                    label: 'Minutes',
                    data: Object.values(stressData),
                    backgroundColor: [
                        '#92C7CF',
                        '#B5C0D0',
                        '#CCD3CA',
                        '#F5E8DD',
                        '#EED3D9',
                        '#F1FADA',
                        '#E1AFD1',
                        '#FFB5DA',
                        '#EEA5A6'
                    ],
                    
                    borderWidth: 1
                }]
            },
            options: {
                responsive: false, // Make chart not responsive
                aspectRatio: 1,
                plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                }
    }
                // title: {
                //     display: true,
                //     text: 'Demon Types Distribution'
                // },
                //         legend: {
                    //         position: 'right', // Place legends at the bottom
                    //         align: 'middle' // Align legends to the center
                    // }
                    
                }
            });
        }
        if (Object.keys(foodData).length !== 0) {
        var myPieChart3 = new Chart(ctx3, {
            type: 'pie',
            data: {
                labels: Object.keys(foodData),
                datasets: [{
                    label: 'Calories',
                    data: Object.values(foodData),
                    backgroundColor: [
                        '#92C7CF',
                        '#B5C0D0',
                        '#CCD3CA',
                        '#F5E8DD',
                        '#EED3D9',
                        '#F1FADA',
                        '#E1AFD1',
                        '#FFB5DA'
                    ],
                    
                    borderWidth: 1
                }]
            },
            options: {
                responsive: false, // Make chart not responsive
                
                // title: {
                //     display: true,
                //     text: 'Demon Types Distribution'
                // }
                
                          aspectRatio: 1,
                plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                }
            }

            }
        });
    }

        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Water Intake',
                data: values,
                backgroundColor: '#BBE2EC', // Blue
                borderColor: 'rgba(54, 162, 235, 1)', // Blue
                borderWidth: 1,
                barPercentage: 0.4, // Adjust the width of the bars
                categoryPercentage: 0.8 // Adjust the space between the bars
            }
            // {
            //     label: 'Average Water Intake',
            //     data: [waterData['Average Water']],
            //     backgroundColor: 'rgba(255, 99, 132, 0.2)', // Red
            //     borderColor: 'rgba(255, 99, 132, 1)', // Red
            //     borderWidth: 1,
            //     barPercentage: 0.5, // Adjust the width of the bars
            //     categoryPercentage: 0.8 // Adjust the space between the bars
            // }
        ]
        },
        options: {
            scales: {
                y: {
                    
                    stacked: true,
                    title: {
                        display: true,
                        text: 'Amount (in Lt)'
                    }
                },
            }
        }
    });

        var ctx5 = document.getElementById('myChart2').getContext('2d');
        var myChart = new Chart(ctx5, {
        type: 'bar',
        data: {
            labels: labels2,
            datasets: [{
                label: 'Sleep Time',
                data: values2,
                backgroundColor: '#FFEAA7', // Blue
                borderColor: '#FFBB64', // Blue
                borderWidth: 1,
                barPercentage: 0.4, // Adjust the width of the bars
                categoryPercentage: 0.8 // Adjust the space between the bars
            },]
        },
        options: {
            scales: {
                y: {
                    
                    stacked: true,
                    title: {
                        display: true,
                        text: 'Hours'
                    }
                },
            }
        }
    });
    </script>
</body>
</html>