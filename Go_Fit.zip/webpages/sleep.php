<?php 
session_start();
include '../backend/dbconnect.php';
if(!isset($_SESSION['User']))  
{
  header("Location: login.php?msg=Please login first!");
  session_destroy();
}
?>
<?php include 'navbarmain.php' ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="../styling/sleep.css">
    <title>Sleep</title>
        <style>
/* Increase the size of the arrow buttons */
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
  
  padding: 20px;
}


</style>
  </head>
  <body>
    
    <!-- <nav class="navbar navbar-expand-lg bg-primary">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" href="dietchoices.php">Diet Choices</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="waterintake.php">Water Intake</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="sleep.php">Sleep</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="physicalactivities.php">Physical Activities</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="stressrelivingactivities.php">Stress Relieving Activities</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="result.php">Result</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="demo.php">Your Activity</a>
            </li>
          </ul>
          <span class = "navbar-brand" href = "#">
            Hello, <?php echo $_SESSION['User'] ?>
            <a href = "../backend/logout.php">
              <img src = "../images/logout.png" class="logout">
            </a>
          </span>
        </div>
      </div>
    </nav> -->

    <form action="../backend/backendsleep.php" method = "post">

        <div class="opt">
        <h1>How many hours did you sleep today?</h1><br>
        <div class="row align-items-center">
            <div class="col-md-5">
                <img src="../images/moon1.png" class="child child1 img-fluid">
            </div>
            <!-- <div class="col-md-4">
                <img src="../images/counter.jpeg" class="counter-button child img-fluid" id="increment-button">
            </div> -->
            <div class="col-md-4">
                <input type="number" min="0" class="form-control counter-value child shadow-none" id="counter-value" name="sleep" value="0">
            </div>
        </div>
        </div>



        
        <!-- <div class="opt"><input type="submit" value="Submit" class="btn btn-success"></div> -->
        <div class="opt"><button class="btn btn-success" onClick="location.href='result.php';">Submit</button></div>
    </form>

  <script>
    const incrementButton = document.getElementById('increment-button');
    const counterValueInput = document.getElementById('counter-value');

    // Add click event listener to the increment button
    incrementButton.addEventListener('click', function() {
        // Get the current value of the counter input
        let currentValue = parseInt(counterValueInput.value);

        // Increment the counter value by 1
        currentValue++;

        // Update the value of the counter input
        counterValueInput.value = currentValue;
    });
  </script>
     
  </body>
</html>