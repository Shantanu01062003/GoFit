<?php
    session_start();
    if(!isset($_SESSION['User']))  
    {
        header("Location: login.php?msg=Please login first!");
        session_destroy();
    }
    include('../backend/dbconnect.php');
    $email = $_SESSION['email'];





    $query = "SELECT COALESCE(SUM(Jogging), 0) FROM physical_activity WHERE Email = '$email';";
    $j = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Exercise), 0) FROM physical_activity WHERE Email = '$email';";
    $e = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Cycling), 0) FROM physical_activity WHERE Email = '$email';";
    $c = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Playing), 0) FROM physical_activity WHERE Email = '$email';";
    $p = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Hiking), 0) FROM physical_activity WHERE Email = '$email';";
    $h = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Other_Physical), 0) FROM physical_activity WHERE Email = '$email';";
    $o = mysqli_fetch_array(mysqli_query($conn, $query))[0];






  
    $query = "SELECT COUNT(*) FROM physical_activity WHERE Email = '$email';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        if ($row[0] > 0) {
            // Update cnt2
            $cnt = $row[0];
        } else {
            // Set cnt2 to 1
            $cnt = 1;
        }
    } else {
        // Handle query error
        $cnt = 1; // Default to 1 in case of error
    }



    


    $tot = $j + $e + $c + $p + $h + $o;
    $avg = round(($tot / $cnt),2);
    $j = round(($j / $cnt),2);
    $e = round(($e / $cnt),2);
    $c = round(($c / $cnt),2);
    $p = round(($p / $cnt),2);
    $h = round(($h / $cnt),2);
    $o = round(($o / $cnt),2);







    $currentDate = date("Y-m-d");
    $email = $_SESSION['email'];



    $query = "SELECT COALESCE(Jogging, 0) FROM physical_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $j1 = $row ? $row[0] : 0;
    } else {
        $j1 = 0; // Set default value to 0 if query fails
    }


    //$query = "SELECT COALESCE(Exercise, 0) FROM physical_activity WHERE Email = '$email' AND Date = '$currentDate';";
    //$e1 = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(Exercise, 0) FROM physical_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $e1 = $row ? $row[0] : 0;
    } else {
        $e1 = 0; // Set default value to 0 if query fails
    }


    $query = "SELECT COALESCE(Cycling, 0) FROM physical_activity WHERE Email = '$email' AND Date = '$currentDate';";
    //$c1 = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $c1 = $row ? $row[0] : 0;
    } else {
        $c1 = 0; // Set default value to 0 if query fails
    }

    $query = "SELECT COALESCE(Playing, 0) FROM physical_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $p1 = $row ? $row[0] : 0;
    } else {
        $p1 = 0; // Set default value to 0 if query fails
    }

    $query = "SELECT COALESCE(Hiking, 0) FROM physical_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $h1 = $row ? $row[0] : 0;
    } else {
        $h1 = 0; // Set default value to 0 if query fails
    }

    $query = "SELECT COALESCE(Other_Physical, 0) FROM physical_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $o1 = $row ? $row[0] : 0;
    } else {
        $o1 = 0; // Set default value to 0 if query fails
    }





   




    //$query = "SELECT Calories FROM data where Email = '$email' and Date = '$currentDate';"; 
    //$cal1 = mysqli_fetch_array(mysqli_query($conn,$query))[0];
    $tot = $j1 + $e1 + $c1 + $p1 + $h1 + $o1;
?>
<?php include 'navbarmain.php' ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel="stylesheet" href="../styling/result.css">
        <title>Result</title>
        <style>
  /* Style for accordion */
 
  
</style>
    </head>
    <body>
        

    <div>
        <h3>
            Physical Activities
        </h3>
    </div>
    <div class="row">
        <div class="card">
            <img class="card-img-top" src="../images/jogging.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Jogging</h5>
                <p class="txt">Average Jogging time : <?php echo  "<span><b>$j</b></span>";?><span>&nbsp;minutes</span></p>
                <p class="txt">Today's Jogging time : <?php echo  "<span><b>$j1</b></span>";?><span>&nbsp;minutes</span></p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="../images/exercise.jpg" alt="Card image cap" width="20px">
            <div class="card-body">
                <h5 class="card-title">Exercise</h5>
                <p class="txt">Average Exercise time : <?php echo  "<span><b>$e</b></span>";?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's Exercise time : <?php echo  "<span><b>$e1</b></span>";?><span>&nbsp;minutes</span></p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="../images/Cycling.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Cycling</h5>
                <p class="txt">Average Cycling time : <?php echo  "<span><b>$c</b></span>";?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's Cycling time : <?php echo  "<span><b>$c1</b></span>";?><span>&nbsp;minutes</span></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="card">
            <img class="card-img-top" src="../images/playing.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Playing</h5>
                <p class="txt">Average Playing time : <?php echo  "<span><b>$p</b></span>";?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's Playing time : <?php echo  "<span><b>$p1</b></span>";?><span>&nbsp;minutes</span></p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="../images/hiking.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Hiking</h5>
                <p class="txt">Average Hiking time : <?php echo  "<span><b>$h</b></span>";?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's Hiking time : <?php echo  "<span><b>$h1</b></span>";?><span>&nbsp;minutes</span></p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="../images/others.jpeg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">All physical activities</h5>
                <p class="txt">Average physical activities time : <?php echo  "<span><b>$avg</b></span>";?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's physical activities time : <?php echo  "<span><b>$tot</b></span>";?><span>&nbsp;minutes</span></p>
            </div>
        </div>
    </div>







<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>    </body>

</html>
