<?php
    session_start();
    if(!isset($_SESSION['User']))  
    {
        header("Location: login.php?msg=Please login first!");
        session_destroy();
    }
    include('../backend/dbconnect.php');
    $email = $_SESSION['email'];



    $query = "SELECT COALESCE(SUM(Chanting), 0) FROM stress_activity WHERE Email = '$email';";
    $c = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Yoga), 0) FROM stress_activity WHERE Email = '$email';";
    $y = mysqli_fetch_array(mysqli_query($conn, $query))[0];
    $query = "SELECT COALESCE(SUM(Meditation), 0) FROM stress_activity WHERE Email = '$email';";
    $m = mysqli_fetch_array(mysqli_query($conn, $query))[0];












    $query = "SELECT COUNT(*) FROM stress_activity WHERE Email = '$email';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        if ($row[0] > 0) {
            // Update cnt2
            $cnt2 = $row[0];
        } else {
            // Set cnt2 to 1
            $cnt2 = 1;
        }
    } else {
        // Handle query error
        $cnt2 = 1; // Default to 1 in case of error
    }









    $c = round(($c / $cnt2),2);
    $y = round(($y / $cnt2),2);
    $m = round(($m / $cnt2),2);







    $currentDate = date("Y-m-d");
    $email = $_SESSION['email'];


    $query = "SELECT COALESCE(Chanting, 0) FROM stress_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $c1 = $row ? $row[0] : 0;
    } else {
        $c1 = 0; // Set default value to 0 if query fails
    }

    $query = "SELECT COALESCE(Yoga, 0) FROM stress_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $y1 = $row ? $row[0] : 0;
    } else {
        $y1 = 0; // Set default value to 0 if query fails
    }

    $query = "SELECT COALESCE(Meditation, 0) FROM stress_activity WHERE Email = '$email' AND Date = '$currentDate';";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $row = mysqli_fetch_array($result);
        $m1 = $row ? $row[0] : 0;
    } else {
        $m1 = 0; // Set default value to 0 if query fails
    }



?>
<?php include 'navbarmain.php' ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel="stylesheet" href="../styling/result.css">
        <title>Result</title>
        <style>
  /* Style for accordion */
 
  
</style>
    </head>
    <body>
        






<div>
    <h3>Stress Relieving Activities</h3>
    <div class="row">
        <div class="card">
            <img class="card-img-top" src="../images/chanting.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Chanting</h5>
                <p class="txt">Average Chanting time : <?php echo "<span><b>$c</b></span>"; ?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's Chanting time : <?php echo "<span><b>$c1</b></span>"; ?><span>&nbsp;minutes</span></p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="../images/yoga.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Yoga</h5>
                <p class="txt">Average Yoga time : <?php echo "<span><b>$y</b></span>"; ?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's Yoga time : <?php echo "<span><b>$y1</b></span>"; ?><span>&nbsp;minutes</span></p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="../images/meditation.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Meditation</h5>
                <p class="txt">Average Meditation time : <?php echo "<span><b>$m</b></span>"; ?><span>&nbsp;minutes</span></p>
                <p class="txt txt1">Today's Meditation time : <?php echo "<span><b>$m1</b></span>"; ?><span>&nbsp;minutes</span></p>
            </div>
        </div>
    </div>
</div>




<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>    </body>

</html>
